import tkinter
from functools import partial
from tkinter import *
import sqlite3
import tkinter.messagebox

root = Tk()
root.title("SR Banking System")
width = 1000
height = 600
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
x = (screen_width / 2) - (width / 2)
y = (screen_height / 2) - (height / 2)
root.geometry("%dx%d+%d+%d" % (width, height, x, y))
root.resizable(0, 0)


def db():
    global conn, cursor
    conn = sqlite3.connect("SRBank.db")
    cursor = conn.cursor()
    cursor.execute(
        "CREATE TABLE IF NOT EXISTS `member` (mem_id INTEGER NOT NULL PRIMARY KEY  AUTOINCREMENT, username TEXT, password TEXT, balance INTEGER )")
    cursor.execute("SELECT * FROM `member` WHERE `username` = 'admin' AND `password` = 'admin'")
    if cursor.fetchone() is None:
        cursor.execute("INSERT INTO `member` (username, password, balance) VALUES('admin', 'admin', '10000')")
        conn.commit()


def Login():
    db()
    if USERNAME.get() == "" or PASSWORD.get() == "":
        lbl_text.config(text="Please fill the required field!", fg="red")
    else:
        cursor.execute("SELECT * FROM `member` WHERE `username` = ? AND `password` = ?",
                       (USERNAME.get(), PASSWORD.get()))
        if cursor.fetchone() is not None:
            HomeWindow(USERNAME.get())
            USERNAME.set("")
            PASSWORD.set("")
            lbl_text.config(text="")
        else:
            lbl_text.config(text="Invalid username or password", fg="red")
            USERNAME.set("")
            PASSWORD.set("")
    cursor.close()
    conn.close()


def HomeWindow(USERNAME):
    global rootwn
    print(USERNAME)
    rootwn = tkinter.Tk()
    rootwn.geometry("1000x600")
    rootwn.title("SR BANK")
    fr1 = tkinter.Frame(rootwn)
    fr1.pack(side="top")
    l_title = tkinter.Message(rootwn, text="SR BANKING SYSTEM", relief="raised", width=1000, padx=600, pady=0,
                              fg="black", justify="center", anchor="center")
    l_title.config(font=("blue", "20", "bold"))
    l_title.pack(side="top")
    label = tkinter.Label(rootwn, text="Welcome " + USERNAME, relief="raised",width=80, padx=100,
                          anchor="center", justify="center")
    label.config(font=("yellow", "14", "bold"))
    label.pack(side="top")

    credit = Button(rootwn, text="Deposit", width=45,height=5,command=partial(deposit,USERNAME))
    credit.pack(side="top")
    credit.bind('<Return>', )
    debit = Button(rootwn, text="Withdraw", width=45, height=5,command=partial(withdraw,USERNAME))
    debit.pack(side="top")
    debit.bind('<Return>', )

    balance = Button(rootwn, text="Balance", width=45,height=5,command=partial(balancepage,USERNAME))
    balance.pack(side="top")
    balance.bind('<Return>')

    logout = Button(rootwn, text="Logout", width=45,height=5,command=logout1)
    logout.pack(side="top")
    logout.bind('<Return>')

    credit.place(x=100,y=150)
    debit.place(x=100,y=230)
    balance.place(x=100,y=310)
    logout.place(x=100,y=390)


def balancepage(USERNAME):
    print(USERNAME)
    global balance_screen
    balance_screen = Toplevel()
    balance_screen.title("balance enquiry")
    balance_screen.geometry("1000x500")
    con = sqlite3.connect("SRBank.db")
    cur = con.cursor()
    cur.execute("SELECT balance FROM member WHERE username = ?",[USERNAME])
    BALANCE = cur.fetchone()
    print(BALANCE)
    Label = tkinter.Label(balance_screen, text="Available Balance is:" + format(BALANCE[0]), relief="raised", bg="black", fg="white",
                          anchor="center", justify="center")
    Label.pack(side="top")

def deposit(USERNAME):

    global a2
    global deposit_screen
    mode = tkinter.StringVar()
    a1 = tkinter.StringVar()
    deposit_screen = tkinter.Tk()
    deposit_screen.title("deposit")
    deposit_screen.geometry("1000x500")

    amount_lable = Label(deposit_screen, text="Amount * ")
    amount_lable.pack()
    a2 = tkinter.Entry(deposit_screen, textvariable=a1)
    a2.pack()
    mode = "deposit"
    # account_lable = Label(deposit_screen, text="Account number * ")
    # Label(deposit_screen, text="").pack()
    Button(deposit_screen, text="deposit", width=10, height=1, bg="white", command=partial(save,USERNAME,a2,mode)).pack()


def withdraw(USERNAME):

    global a2
    global withdraw_screen
    a1 = tkinter.StringVar()
    mode = tkinter.StringVar()

    # withdraw_screen = Toplevel()
    withdraw_screen = tkinter.Tk()
    withdraw_screen.title("Withdraw")
    withdraw_screen.geometry("1000x500")

    amount_lable = Label(withdraw_screen, text="Amount * ")
    amount_lable.pack()
    a2 = tkinter.Entry(withdraw_screen, textvariable=a1)
    a2.pack()
    mode = "withdraw"
    Button(withdraw_screen, text="withdraw", width=10, height=1, bg="white", command=partial(save,USERNAME,a2,mode)).pack()

def logout1():
    rootwn.destroy()
    root.deiconify()


def save(USERNAME,a1,mode):

    global name
    print(mode)
    content = a2.get()
    print(content)
    con = sqlite3.connect("SRBank.db")
    cur = con.cursor()
    cur.execute("SELECT balance FROM member WHERE username = ?", [USERNAME])
    con.commit()
    BALANCE = cur.fetchone()
    balance = format(BALANCE[0])
    print(balance)
    bal = int(balance)
    con = int(content)
    if mode == "deposit":
        name = bal + con
        update(USERNAME)
        tkinter.messagebox.showinfo("Success", "Amount credited successfully to your account.!", parent=deposit_screen)
    elif mode == "withdraw":
        if bal < con:
            tkinter.messagebox.showerror("Error","Insufficient Balance",parent=withdraw_screen)
        else:
            name = bal - con
            update(USERNAME)
            tkinter.messagebox.showinfo("Success", "Amount debited successfully from your account.!",parent=withdraw_screen)

def update(USERNAME):
    con1 = sqlite3.connect("SRBank.db")
    cur1 = con1.cursor()
    balance = name
    cur1.execute('''UPDATE member SET balance =? WHERE username = ?''', (balance, USERNAME))
    print(name)
    con1.commit()
    con1.close()



USERNAME = StringVar()
PASSWORD = StringVar()
BALANCE = IntVar()

bg = PhotoImage(file = "bank.gif")
Top = Frame(root, bd=2, relief=RIDGE)
Top.pack(side=TOP, fill=X)
Form = Frame(root, height=200)
Form.pack(side=TOP, pady=20)

lbl_title = Label(Top, text="SR Bank", font=('arial', 15))
lbl_title.pack(fill=X)
lbl_username = Label(Form, text="Username:", font=('arial', 14), bd=15)
lbl_username.grid(row=0, sticky="e")
lbl_password = Label(Form, text="Password:", font=('arial', 14), bd=15)
lbl_password.grid(row=1, sticky="e")
lbl_text = Label(Form)
lbl_text.grid(row=2, columnspan=2)

username = Entry(Form, textvariable=USERNAME, font=(14))
username.grid(row=0, column=1)
password = Entry(Form, textvariable=PASSWORD, show="*", font=(14))
password.grid(row=1, column=1)


btn_login = Button(Form, text="Login", width=45, command=Login)
btn_login.grid(pady=25, row=3, columnspan=2)
btn_login.bind('<Return>', Login)

root.mainloop()
